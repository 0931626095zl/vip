import requests

r = requests.get('https://api.proxyscrape.com/?request=displayproxies&proxytype=http&country=all')

proxies = r.text.split('\n')

f = open('proxy.txt', 'w')
# print(proxies)
for proxy in proxies:
    f.write(proxy)
f.close